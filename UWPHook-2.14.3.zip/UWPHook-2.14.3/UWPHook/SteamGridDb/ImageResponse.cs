﻿namespace UWPHook.SteamGridDb
{
    /// <summary>
    /// Represents an image from SteamGridDB
    /// </summary>
    public class ImageResponse
    {
        public string Url { get; set; }
    }
}